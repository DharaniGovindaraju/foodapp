import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CustomerlocationPage } from './customerlocation';

@NgModule({
  declarations: [
    CustomerlocationPage,
  ],
  imports: [
    IonicPageModule.forChild(CustomerlocationPage),
  ],
})
export class CustomerlocationPageModule {}
