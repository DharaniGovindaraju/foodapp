import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CooklocationPage } from './cooklocation';

@NgModule({
  declarations: [
    CooklocationPage,
  ],
  imports: [
    IonicPageModule.forChild(CooklocationPage),
  ],
})
export class CooklocationPageModule {}
